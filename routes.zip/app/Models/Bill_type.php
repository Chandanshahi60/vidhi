<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bill_type extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $table = 'bill_type';

}
