<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notice_tenant extends Model
{
    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
	protected $table = 'notice_tenant';
}
