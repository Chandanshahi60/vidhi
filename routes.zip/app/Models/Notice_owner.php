<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notice_owner extends Model
{
    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
	protected $table = 'notice_owner';
}
