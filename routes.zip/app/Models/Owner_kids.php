<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Owner_kids extends Model
{
    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
	protected $table = 'owner_kids';
}
